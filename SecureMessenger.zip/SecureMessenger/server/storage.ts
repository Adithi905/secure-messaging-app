import {
  users, contacts, messages, blocks, transactions,
  type User, type InsertUser,
  type Contact, type InsertContact,
  type Message, type InsertMessage,
  type Block, type InsertBlock,
  type Transaction, type InsertTransaction
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  
  // Contact operations
  getContact(id: number): Promise<Contact | undefined>;
  createContact(contact: InsertContact): Promise<Contact>;
  getContactsByUserId(userId: number): Promise<Contact[]>;
  getAllContacts(): Promise<Contact[]>;
  
  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getMessageById(id: number): Promise<Message | undefined>;
  getMessagesByUsers(user1Id: number, user2Id: number): Promise<Message[]>;
  updateMessageTransaction(id: number, transactionHash: string): Promise<Message>;
  updateMessageConfirmations(id: number, confirmations: number): Promise<Message>;
  updateMessageStatus(id: number, verified: boolean, confirmations: number): Promise<Message>;
  getAllMessages(): Promise<Message[]>;
  
  // Block operations
  createBlock(block: InsertBlock): Promise<Block>;
  getBlock(id: number): Promise<Block | undefined>;
  getBlockByHash(hash: string): Promise<Block | undefined>;
  
  // Transaction operations
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransaction(id: number): Promise<Transaction | undefined>;
  getTransactionByHash(hash: string): Promise<Transaction | undefined>;
  getTransactionsByMessageId(messageId: number): Promise<Transaction[]>;
  updateTransactionConfirmations(hash: string, confirmations: number): Promise<Transaction | undefined>;
  updateTransactionStatus(hash: string, status: string, confirmations: number): Promise<Transaction | undefined>;
  getPendingTransactions(): Promise<Transaction[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contacts: Map<number, Contact>;
  private messages: Map<number, Message>;
  private blocks: Map<number, Block>;
  private transactions: Map<number, Transaction>;
  
  private userId: number;
  private contactId: number;
  private messageId: number;
  private blockId: number;
  private transactionId: number;
  
  constructor() {
    this.users = new Map();
    this.contacts = new Map();
    this.messages = new Map();
    this.blocks = new Map();
    this.transactions = new Map();
    
    this.userId = 1;
    this.contactId = 1;
    this.messageId = 1;
    this.blockId = 1;
    this.transactionId = 1;
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  // Contact operations
  async getContact(id: number): Promise<Contact | undefined> {
    return this.contacts.get(id);
  }
  
  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = this.contactId++;
    const now = new Date();
    const contact: Contact = { ...insertContact, id, createdAt: now };
    this.contacts.set(id, contact);
    return contact;
  }
  
  async getContactsByUserId(userId: number): Promise<Contact[]> {
    return Array.from(this.contacts.values()).filter(contact => contact.userId === userId);
  }
  
  async getAllContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values());
  }
  
  // Message operations
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const now = new Date();
    const message: Message = {
      ...insertMessage,
      id,
      transactionHash: null,
      blockConfirmations: 0,
      verified: false,
      createdAt: now
    };
    this.messages.set(id, message);
    return message;
  }
  
  async getMessageById(id: number): Promise<Message | undefined> {
    return this.messages.get(id);
  }
  
  async getMessagesByUsers(user1Id: number, user2Id: number): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(message => 
      (message.senderId === user1Id && message.receiverId === user2Id) ||
      (message.senderId === user2Id && message.receiverId === user1Id)
    );
  }
  
  async updateMessageTransaction(id: number, transactionHash: string): Promise<Message> {
    const message = this.messages.get(id);
    if (!message) {
      throw new Error(`Message with id ${id} not found`);
    }
    
    const updatedMessage = {
      ...message,
      transactionHash
    };
    
    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }
  
  async updateMessageConfirmations(id: number, confirmations: number): Promise<Message> {
    const message = this.messages.get(id);
    if (!message) {
      throw new Error(`Message with id ${id} not found`);
    }
    
    const updatedMessage = {
      ...message,
      blockConfirmations: confirmations
    };
    
    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }
  
  async updateMessageStatus(id: number, verified: boolean, confirmations: number): Promise<Message> {
    const message = this.messages.get(id);
    if (!message) {
      throw new Error(`Message with id ${id} not found`);
    }
    
    const updatedMessage = {
      ...message,
      verified,
      blockConfirmations: confirmations
    };
    
    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }
  
  async getAllMessages(): Promise<Message[]> {
    return Array.from(this.messages.values());
  }
  
  // Block operations
  async createBlock(insertBlock: InsertBlock): Promise<Block> {
    const id = this.blockId++;
    const now = new Date();
    const block: Block = {
      ...insertBlock,
      id,
      timestamp: now
    };
    this.blocks.set(id, block);
    return block;
  }
  
  async getBlock(id: number): Promise<Block | undefined> {
    return this.blocks.get(id);
  }
  
  async getBlockByHash(hash: string): Promise<Block | undefined> {
    return Array.from(this.blocks.values()).find(block => block.blockHash === hash);
  }
  
  // Transaction operations
  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.transactionId++;
    const now = new Date();
    const transaction: Transaction = {
      ...insertTransaction,
      id,
      blockId: null,
      createdAt: now
    };
    this.transactions.set(id, transaction);
    return transaction;
  }
  
  async getTransaction(id: number): Promise<Transaction | undefined> {
    return this.transactions.get(id);
  }
  
  async getTransactionByHash(hash: string): Promise<Transaction | undefined> {
    return Array.from(this.transactions.values()).find(tx => tx.transactionHash === hash);
  }
  
  async getTransactionsByMessageId(messageId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(tx => tx.messageId === messageId);
  }
  
  async updateTransactionConfirmations(hash: string, confirmations: number): Promise<Transaction | undefined> {
    const transaction = Array.from(this.transactions.values()).find(tx => tx.transactionHash === hash);
    if (!transaction) {
      return undefined;
    }
    
    const updatedTransaction = {
      ...transaction,
      blockConfirmations: confirmations
    };
    
    this.transactions.set(transaction.id, updatedTransaction);
    return updatedTransaction;
  }
  
  async updateTransactionStatus(hash: string, status: string, confirmations: number): Promise<Transaction | undefined> {
    const transaction = Array.from(this.transactions.values()).find(tx => tx.transactionHash === hash);
    if (!transaction) {
      return undefined;
    }
    
    const updatedTransaction = {
      ...transaction,
      status,
      blockConfirmations: confirmations,
      blockId: status === 'confirmed' ? this.blockId : null
    };
    
    this.transactions.set(transaction.id, updatedTransaction);
    return updatedTransaction;
  }
  
  async getPendingTransactions(): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(tx => tx.status === 'pending');
  }
}

export const storage = new MemStorage();
