import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer, WebSocket } from "ws";
import { insertUserSchema, insertContactSchema, insertMessageSchema } from "@shared/schema";
import { encryptMessage } from "./blockchain";
import crypto from "crypto";
import cors from "cors";

// Store active WebSocket connections
const clients = new Map<number, WebSocket>();

export async function registerRoutes(app: Express): Promise<Server> {
  // Add CORS middleware to allow connections
  app.use(cors({
    origin: true,
    credentials: true
  }));
  
  const httpServer = createServer(app);
  
  // WebSocket functionality temporarily disabled for debugging
  console.log('WebSocket server disabled for debugging');
  
  // Define a no-op broadcast function since WebSockets are disabled
  const broadcast = (userId: number, data: any) => {
    // This is a no-op function - clients will poll for updates instead
    console.log(`Would broadcast to user ${userId}:`, data);
  };
  
  // User routes
  app.post('/api/users', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: 'Invalid user data' });
    }
  });
  
  app.get('/api/users/current', async (req, res) => {
    // In a real app, this would use the session to identify the user
    // For this demo, we'll just use the first user
    try {
      const users = await storage.getAllUsers();
      if (users.length > 0) {
        res.json(users[0]);
      } else {
        res.status(404).json({ message: 'No user found' });
      }
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });
  
  // Contact routes
  app.post('/api/contacts', async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(contactData);
      
      // Notify user about new contact via WebSocket
      broadcast(contactData.userId, {
        type: 'NEW_CONTACT',
        contact
      });
      
      res.json(contact);
    } catch (error) {
      res.status(400).json({ message: 'Invalid contact data' });
    }
  });
  
  app.get('/api/contacts', async (req, res) => {
    try {
      // In a real app, would filter by current user from session
      const contacts = await storage.getAllContacts();
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });
  
  // Message routes
  app.post('/api/messages', async (req, res) => {
    try {
      console.log("Received message data:", req.body);
      const messageData = insertMessageSchema.parse(req.body);
      console.log("Parsed message data:", messageData);
      
      // Get sender
      const sender = await storage.getUser(messageData.senderId);
      if (!sender) {
        return res.status(404).json({ message: 'Sender not found' });
      }
      
      // Get contact (instead of user)
      const contact = await storage.getContact(messageData.receiverId);
      if (!contact) {
        return res.status(404).json({ message: 'Contact not found' });
      }
      
      // Use the contact's public key directly
      const receiverPublicKey = contact.publicKey;
      
      // Encrypt message with a simple mock function for testing
      const encryptedContent = `encrypted:${messageData.content}`;
      console.log("Encrypted content:", encryptedContent);
      
      // Create message with encrypted content
      const message = await storage.createMessage({
        ...messageData,
        encryptedContent
      });
      
      // Create transaction for blockchain
      const transactionHash = crypto
        .createHash('sha256')
        .update(`${message.id}-${encryptedContent}-${Date.now()}`)
        .digest('hex');
      
      // Update message with transaction hash
      const updatedMessage = await storage.updateMessageTransaction(
        message.id,
        transactionHash
      );
      
      // Create transaction record
      await storage.createTransaction({
        transactionHash,
        messageId: message.id,
        status: 'pending'
      });
      
      // Notify sender and receiver via WebSocket
      broadcast(messageData.senderId, {
        type: 'NEW_MESSAGE',
        message: updatedMessage,
        senderId: messageData.senderId,
        receiverId: messageData.receiverId
      });
      
      broadcast(messageData.receiverId, {
        type: 'NEW_MESSAGE',
        message: updatedMessage,
        senderId: messageData.senderId,
        receiverId: messageData.receiverId
      });
      
      res.json(updatedMessage);
      
      // Start blockchain confirmation process (simulated)
      simulateBlockchainConfirmation(updatedMessage.id, transactionHash, broadcast);
      
    } catch (error) {
      console.error('Message error:', error);
      res.status(400).json({ message: 'Invalid message data' });
    }
  });
  
  app.get('/api/messages', async (req, res) => {
    try {
      const messages = await storage.getAllMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });
  
  app.get('/api/messages/:contactId', async (req, res) => {
    try {
      const contactId = parseInt(req.params.contactId);
      const contact = await storage.getContact(contactId);
      
      if (!contact) {
        return res.status(404).json({ message: 'Contact not found' });
      }
      
      // Get current user (first user for demo)
      const users = await storage.getAllUsers();
      const currentUser = users[0];
      
      if (!currentUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Get messages between current user and this contact (using contact ID as receiver ID)
      const messages = await storage.getMessagesByUsers(currentUser.id, contactId);
      console.log(`Fetched ${messages.length} messages for user ${currentUser.id} and contact ${contactId}`);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: 'Server error' });
    }
  });
  
  // Blockchain routes
  app.get('/api/blockchain/transactions/pending', async (req, res) => {
    try {
      const transactions = await storage.getPendingTransactions();
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });
  
  app.get('/api/blockchain/transactions/message/:messageId', async (req, res) => {
    try {
      const messageId = parseInt(req.params.messageId);
      const transactions = await storage.getTransactionsByMessageId(messageId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });
  
  app.get('/api/blockchain/transactions/:transactionId', async (req, res) => {
    try {
      const transactionId = parseInt(req.params.transactionId);
      const transaction = await storage.getTransaction(transactionId);
      
      if (!transaction) {
        return res.status(404).json({ message: 'Transaction not found' });
      }
      
      res.json(transaction);
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });

  return httpServer;
}

// Simulate the blockchain confirmation process
async function simulateBlockchainConfirmation(
  messageId: number, 
  transactionHash: string,
  broadcast: (userId: number, data: any) => void
) {
  try {
    // Simulated blockchain confirmation process
    // In a real implementation, this would interact with an actual blockchain
    
    // After 5 seconds, update to 1 confirmation
    setTimeout(async () => {
      const transaction = await storage.updateTransactionConfirmations(
        transactionHash,
        1
      );
      
      if (transaction) {
        const message = await storage.getMessageById(messageId);
        if (message) {
          await storage.updateMessageConfirmations(messageId, 1);
          
          // Notify users
          broadcast(message.senderId, {
            type: 'TRANSACTION_UPDATE',
            transactionHash,
            confirmations: 1
          });
          
          broadcast(message.receiverId, {
            type: 'TRANSACTION_UPDATE',
            transactionHash,
            confirmations: 1
          });
        }
      }
    }, 5000);
    
    // After 10 seconds, update to 2 confirmations
    setTimeout(async () => {
      const transaction = await storage.updateTransactionConfirmations(
        transactionHash,
        2
      );
      
      if (transaction) {
        const message = await storage.getMessageById(messageId);
        if (message) {
          await storage.updateMessageConfirmations(messageId, 2);
          
          // Notify users
          broadcast(message.senderId, {
            type: 'TRANSACTION_UPDATE',
            transactionHash,
            confirmations: 2
          });
          
          broadcast(message.receiverId, {
            type: 'TRANSACTION_UPDATE',
            transactionHash,
            confirmations: 2
          });
        }
      }
    }, 10000);
    
    // After 15 seconds, update to 3 confirmations and mark as confirmed
    setTimeout(async () => {
      const transaction = await storage.updateTransactionStatus(
        transactionHash,
        'confirmed',
        3
      );
      
      if (transaction) {
        const message = await storage.getMessageById(messageId);
        if (message) {
          await storage.updateMessageStatus(messageId, true, 3);
          
          // Notify users
          broadcast(message.senderId, {
            type: 'TRANSACTION_UPDATE',
            transactionHash,
            confirmations: 3,
            status: 'confirmed'
          });
          
          broadcast(message.receiverId, {
            type: 'TRANSACTION_UPDATE',
            transactionHash,
            confirmations: 3,
            status: 'confirmed'
          });
        }
      }
    }, 15000);
    
  } catch (error) {
    console.error('Error in blockchain confirmation:', error);
  }
}
