# Architecture Overview

## Overview

This is a decentralized secure messaging application that provides end-to-end encrypted communication with blockchain verification. The system allows users to send encrypted messages that are verified and tracked using blockchain technology, ensuring message integrity and non-repudiation.

The application follows a client-server architecture with:
- A React-based web frontend
- A Node.js/Express backend
- PostgreSQL database using Drizzle ORM
- End-to-end encryption using Web Crypto API
- Blockchain integration for message verification

## System Architecture

The application follows a modern web application architecture with the following key components:

```
┌────────────────────┐      ┌───────────────────┐      ┌─────────────────────┐
│                    │      │                   │      │                     │
│   React Frontend   │<────>│  Express Backend  │<────>│  PostgreSQL Database│
│                    │      │                   │      │                     │
└────────────────────┘      └───────────────────┘      └─────────────────────┘
         │                           │                           
         │                           │                           
         ▼                           ▼                           
┌────────────────────┐      ┌───────────────────┐                
│                    │      │                   │                
│ Web Crypto API     │      │  Blockchain       │                
│ (Encryption)       │      │  Integration      │                
│                    │      │                   │                
└────────────────────┘      └───────────────────┘                
```

### Frontend Architecture

The frontend is built with React and uses:
- Tailwind CSS for styling
- ShadCN UI component library
- TanStack Query for data fetching and state management
- Web Crypto API for client-side encryption

The UI follows a component-based architecture with separation of concerns between views, components, hooks, and utility functions.

### Backend Architecture

The backend is built with Node.js and Express and provides:
- RESTful API endpoints for user authentication, message sending/receiving
- WebSocket support for real-time messaging
- Blockchain integration for message verification
- Server-side validation and security measures

### Data Storage

Data is stored in a PostgreSQL database with the following key entities:
- Users: Store user information, including encryption keys
- Contacts: Store contact information for each user
- Messages: Store encrypted messages between users
- Blocks: Store blockchain data
- Transactions: Store message transaction records

## Key Components

### Frontend Components

1. **Authentication System**
   - User registration and login
   - Key pair generation and management
   - Session management

2. **Messaging Interface**
   - Contact management (add, view, select contacts)
   - Message composition and sending
   - Real-time message delivery via WebSockets
   - Message encryption and decryption

3. **Blockchain Verification**
   - Transaction status tracking
   - Block confirmations and verification
   - Verification status display

### Backend Components

1. **API Layer**
   - RESTful endpoints for all application features
   - WebSocket server for real-time communication
   - Authentication middleware

2. **Storage Layer**
   - Database access via Drizzle ORM
   - Schema definitions and migrations
   - Query optimization

3. **Blockchain Integration**
   - Transaction creation and verification
   - Block mining and validation
   - Consensus mechanism (simplified implementation)

4. **Cryptography Service**
   - Key management
   - Message encryption/decryption
   - Digital signatures for blockchain transactions

### Database Schema

The database schema consists of five main tables:

1. **Users**
   - id (primary key)
   - username
   - publicKey
   - privateKey
   - createdAt

2. **Contacts**
   - id (primary key)
   - userId (foreign key to users.id)
   - name
   - publicKey
   - createdAt

3. **Messages**
   - id (primary key)
   - senderId (foreign key to users.id)
   - receiverId (foreign key to users.id)
   - content (original content)
   - encryptedContent
   - transactionHash
   - blockConfirmations
   - verified
   - createdAt

4. **Blocks**
   - id (primary key)
   - blockHash
   - previousHash
   - timestamp
   - transactionHashes
   - nonce

5. **Transactions**
   - id (primary key)
   - transactionHash
   - messageId (foreign key to messages.id)
   - blockId (foreign key to blocks.id)
   - status
   - createdAt

## Data Flow

### Message Sending Flow

1. User composes a message to a contact
2. Frontend encrypts the message using the recipient's public key
3. Encrypted message is sent to the backend via API
4. Backend stores the encrypted message in the database
5. Backend creates a blockchain transaction for the message
6. Backend sends real-time update to the recipient via WebSocket
7. Recipient receives the message notification
8. Recipient's client decrypts the message using their private key
9. Message is displayed to the recipient

### Blockchain Verification Flow

1. New message transactions are placed in a pending queue
2. Backend periodically processes the queue and mines new blocks
3. Once a block is mined, the transactions within it are marked as confirmed
4. Block confirmations increase as new blocks reference previous ones
5. Messages with confirmed transactions are marked as verified
6. UI displays verification status to users

## External Dependencies

### Frontend Dependencies

- React: UI framework
- TanStack Query: Data fetching and state management
- Tailwind CSS: Styling
- Radix UI/ShadCN: UI component primitives
- Web Crypto API: Cryptographic operations
- WebSocket API: Real-time communication

### Backend Dependencies

- Node.js: Runtime environment
- Express: Web server framework
- Drizzle ORM: Database ORM
- Neon Database: PostgreSQL provider
- WebSockets: Real-time communication
- Crypto (Node.js): Cryptographic operations
- Vite: Development and build tool

## Deployment Strategy

The application is deployed on Replit with:

- Configuration for Node.js 20 and PostgreSQL 16
- Development mode using `npm run dev`
- Production mode using `npm run start`
- Build process using Vite for the frontend and esbuild for the backend
- Autoscaling deployment target
- Port mapping from local port 5000 to external port 80

### Development Workflow

1. Development with hot-reloading for frontend and backend
2. Database migrations using Drizzle Kit
3. TypeScript type checking
4. Production build creates optimized assets

### Environment Configuration

- NODE_ENV: Used to determine development or production mode
- DATABASE_URL: Required for database connection
- Support for local and production environments