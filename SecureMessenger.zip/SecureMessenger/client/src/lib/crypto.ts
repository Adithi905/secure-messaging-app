/**
 * Cryptography utility functions for end-to-end encryption
 * Uses the Web Crypto API for secure client-side cryptography
 */

// Key pair generation
export async function generateKeyPair(): Promise<{ publicKey: string; privateKey: string }> {
  try {
    // Generate RSA key pair
    const keyPair = await window.crypto.subtle.generateKey(
      {
        name: "RSA-OAEP",
        modulusLength: 2048,
        publicExponent: new Uint8Array([0x01, 0x00, 0x01]), // 65537
        hash: "SHA-256",
      },
      true, // extractable
      ["encrypt", "decrypt"] // key usages
    );

    // Export public key to JWK format
    const publicKeyJwk = await window.crypto.subtle.exportKey(
      "jwk",
      keyPair.publicKey
    );

    // Export private key to JWK format
    const privateKeyJwk = await window.crypto.subtle.exportKey(
      "jwk",
      keyPair.privateKey
    );

    // Convert JWK to strings
    return {
      publicKey: JSON.stringify(publicKeyJwk),
      privateKey: JSON.stringify(privateKeyJwk),
    };
  } catch (error) {
    console.error("Error generating key pair:", error);
    throw new Error("Failed to generate encryption keys");
  }
}

// Import a public key from string format
export async function importPublicKey(publicKeyString: string): Promise<CryptoKey> {
  try {
    const publicKeyJwk = JSON.parse(publicKeyString);
    return await window.crypto.subtle.importKey(
      "jwk",
      publicKeyJwk,
      {
        name: "RSA-OAEP",
        hash: "SHA-256",
      },
      true,
      ["encrypt"]
    );
  } catch (error) {
    console.error("Error importing public key:", error);
    throw new Error("Failed to import encryption key");
  }
}

// Import a private key from string format
export async function importPrivateKey(privateKeyString: string): Promise<CryptoKey> {
  try {
    const privateKeyJwk = JSON.parse(privateKeyString);
    return await window.crypto.subtle.importKey(
      "jwk",
      privateKeyJwk,
      {
        name: "RSA-OAEP",
        hash: "SHA-256",
      },
      true,
      ["decrypt"]
    );
  } catch (error) {
    console.error("Error importing private key:", error);
    throw new Error("Failed to import decryption key");
  }
}

// Encrypt message using recipient's public key
export async function encryptMessage(
  message: string,
  publicKeyString: string
): Promise<string> {
  try {
    const publicKey = await importPublicKey(publicKeyString);
    
    // Convert message to Uint8Array
    const encoder = new TextEncoder();
    const messageBytes = encoder.encode(message);
    
    // Encrypt the message
    const encryptedBytes = await window.crypto.subtle.encrypt(
      {
        name: "RSA-OAEP",
      },
      publicKey,
      messageBytes
    );
    
    // Convert encrypted bytes to base64 string
    return arrayBufferToBase64(encryptedBytes);
  } catch (error) {
    console.error("Error encrypting message:", error);
    throw new Error("Failed to encrypt message");
  }
}

// Decrypt message using receiver's private key
export async function decryptMessage(
  encryptedMessage: string,
  privateKeyString: string
): Promise<string> {
  try {
    const privateKey = await importPrivateKey(privateKeyString);
    
    // Convert base64 to ArrayBuffer
    const encryptedBytes = base64ToArrayBuffer(encryptedMessage);
    
    // Decrypt the message
    const decryptedBytes = await window.crypto.subtle.decrypt(
      {
        name: "RSA-OAEP",
      },
      privateKey,
      encryptedBytes
    );
    
    // Convert decrypted bytes to string
    const decoder = new TextDecoder();
    return decoder.decode(decryptedBytes);
  } catch (error) {
    console.error("Error decrypting message:", error);
    throw new Error("Failed to decrypt message");
  }
}

// Utility functions for base64 conversion
export function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

export function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binaryString = window.atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

// Generate a hash for verification
export async function generateHash(data: string): Promise<string> {
  const encoder = new TextEncoder();
  const dataBytes = encoder.encode(data);
  const hashBuffer = await window.crypto.subtle.digest('SHA-256', dataBytes);
  return arrayBufferToBase64(hashBuffer);
}

// Format a public key for display (shortened version)
export function formatPublicKeyShort(publicKey: string): string {
  try {
    const key = JSON.parse(publicKey);
    if (key && key.n) {
      return `0x${key.n.substring(0, 4)}...${key.n.substring(key.n.length - 4)}`;
    }
    return "Invalid key";
  } catch {
    return "Invalid key";
  }
}
