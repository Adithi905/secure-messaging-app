import { generateHash } from "./crypto";

// Interface for blockchain-related types
export interface Block {
  index: number;
  previousHash: string;
  timestamp: number;
  data: string[];
  hash: string;
  nonce: number;
}

export interface Transaction {
  id: string;
  messageId: number;
  hash: string;
  blockId?: number;
  blockHash?: string;
  timestamp: number;
  status: 'pending' | 'confirmed' | 'failed';
  confirmations: number;
}

// Difficulty for proof of work (simulated)
const DIFFICULTY = 2;

// Function to create a transaction for a message
export async function createTransaction(messageId: number, message: string): Promise<Transaction> {
  const timestamp = Date.now();
  const hash = await generateHash(`${messageId}-${message}-${timestamp}`);
  
  return {
    id: generateUUID(),
    messageId,
    hash,
    timestamp,
    status: 'pending',
    confirmations: 0
  };
}

// Function to validate a transaction
export async function validateTransaction(transaction: Transaction): Promise<boolean> {
  // Simulated transaction validation
  // In a real system, this would verify digital signatures, check account balances, etc.
  return true;
}

// Function to create a genesis block (first block in the chain)
export async function createGenesisBlock(): Promise<Block> {
  const timestamp = Date.now();
  const hash = await generateHash(`0-${timestamp}-[]`);
  
  return {
    index: 0,
    previousHash: "0",
    timestamp,
    data: [],
    hash,
    nonce: 0
  };
}

// Function to create a new block with proof of work
export async function mineBlock(
  index: number,
  previousHash: string,
  data: string[],
): Promise<Block> {
  let nonce = 0;
  let timestamp = Date.now();
  let hash = '';
  
  // Proof of work simulation
  while (true) {
    // Calculate hash
    hash = await generateHash(`${index}-${previousHash}-${timestamp}-${JSON.stringify(data)}-${nonce}`);
    
    // Check if hash meets the difficulty requirement (starts with N zeros)
    if (hash.substring(0, DIFFICULTY) === '0'.repeat(DIFFICULTY)) {
      break;
    }
    
    // Increment nonce and try again
    nonce++;
    
    // Update timestamp occasionally to keep it somewhat current
    if (nonce % 100000 === 0) {
      timestamp = Date.now();
    }
  }
  
  return {
    index,
    previousHash,
    timestamp,
    data,
    hash,
    nonce
  };
}

// Function to validate a block
export async function validateBlock(block: Block, previousBlock: Block): Promise<boolean> {
  // Validate block index
  if (block.index !== previousBlock.index + 1) {
    return false;
  }
  
  // Validate previous hash
  if (block.previousHash !== previousBlock.hash) {
    return false;
  }
  
  // Validate block hash
  const calculatedHash = await generateHash(
    `${block.index}-${block.previousHash}-${block.timestamp}-${JSON.stringify(block.data)}-${block.nonce}`
  );
  
  if (calculatedHash !== block.hash) {
    return false;
  }
  
  // Validate proof of work
  if (block.hash.substring(0, DIFFICULTY) !== '0'.repeat(DIFFICULTY)) {
    return false;
  }
  
  return true;
}

// Helper function to generate a UUID
function generateUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// API Calls to the server blockchain service
export async function submitTransaction(messageId: number, encryptedContent: string): Promise<Transaction> {
  try {
    const res = await fetch('/api/blockchain/transactions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ 
        messageId, 
        content: encryptedContent 
      }),
      credentials: 'include',
    });
    
    if (!res.ok) {
      throw new Error('Failed to submit transaction');
    }
    
    return await res.json();
  } catch (error) {
    console.error('Error submitting transaction:', error);
    throw error;
  }
}

export async function getPendingTransactions(): Promise<Transaction[]> {
  try {
    const res = await fetch('/api/blockchain/transactions/pending', {
      credentials: 'include',
    });
    
    if (!res.ok) {
      throw new Error('Failed to get pending transactions');
    }
    
    return await res.json();
  } catch (error) {
    console.error('Error getting pending transactions:', error);
    throw error;
  }
}

export async function getTransactionsByMessage(messageId: number): Promise<Transaction[]> {
  try {
    const res = await fetch(`/api/blockchain/transactions/message/${messageId}`, {
      credentials: 'include',
    });
    
    if (!res.ok) {
      throw new Error('Failed to get message transactions');
    }
    
    return await res.json();
  } catch (error) {
    console.error('Error getting message transactions:', error);
    throw error;
  }
}

export async function getTransactionStatus(transactionId: string): Promise<Transaction> {
  try {
    const res = await fetch(`/api/blockchain/transactions/${transactionId}`, {
      credentials: 'include',
    });
    
    if (!res.ok) {
      throw new Error('Failed to get transaction status');
    }
    
    return await res.json();
  } catch (error) {
    console.error('Error getting transaction status:', error);
    throw error;
  }
}
