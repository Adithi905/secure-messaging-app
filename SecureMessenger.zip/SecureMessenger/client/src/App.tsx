import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import { useState, useEffect, createContext } from "react";
import { User } from "@shared/schema";
import { generateKeyPair } from "./lib/crypto";

// Create context for current user
export interface CurrentUserContextType {
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  isLoading: boolean;
}

// Create context with a default value
const defaultContextValue: CurrentUserContextType = {
  currentUser: null,
  setCurrentUser: () => {},
  isLoading: true
};

// Export the context
export const CurrentUserContext = createContext<CurrentUserContextType>(defaultContextValue);

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomeSimplified} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // On first load, initialize the user
  useEffect(() => {
    console.log("App: Starting user initialization...");
    
    async function initUser() {
      try {
        console.log("Attempting to get current user...");
        
        // Try to get existing user
        const response = await fetch("/api/users/current", {
          credentials: "include"
        });

        console.log("Current user API response:", response.status, response.statusText);

        if (response.ok) {
          // User exists, set currentUser
          const user = await response.json();
          console.log("Retrieved existing user:", user.username);
          setCurrentUser(user);
        } else {
          console.log("No existing user found. Creating new user...");
          
          // No user exists, create a new one with generated keys
          const keys = await generateKeyPair();
          
          // Choose a random username
          const username = `user_${Math.floor(Math.random() * 10000)}`;
          console.log("Generated username:", username);
          
          // Create new user
          const createResponse = await fetch("/api/users", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              username,
              publicKey: keys.publicKey,
              privateKey: keys.privateKey,
            }),
            credentials: "include",
          });

          console.log("Create user API response:", createResponse.status, createResponse.statusText);

          if (createResponse.ok) {
            const newUser = await createResponse.json();
            console.log("New user created:", newUser.username);
            setCurrentUser(newUser);
          } else {
            console.error("Failed to create user");
          }
        }
      } catch (error) {
        console.error("Error initializing user:", error);
      } finally {
        console.log("Setting isLoading to false");
        setIsLoading(false);
      }
    }

    initUser();
  }, []);

  const contextValue = {
    currentUser,
    setCurrentUser,
    isLoading
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <CurrentUserContext.Provider value={contextValue}>
          <Toaster />
          <Router />
        </CurrentUserContext.Provider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
