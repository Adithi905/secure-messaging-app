import React, { useState, useEffect } from 'react';

function SimpleApp() {
  const [username, setUsername] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Test API connection on load
  useEffect(() => {
    async function fetchUser() {
      try {
        console.log("Simple App: Fetching user data...");
        
        const response = await fetch("/api/users/current");
        console.log("API Response:", response.status, response.statusText);
        
        if (response.ok) {
          const userData = await response.json();
          console.log("User data:", userData);
          setUsername(userData.username);
        } else {
          console.log("No user found, creating a new one...");
          
          // Create a test user
          const createResponse = await fetch("/api/users", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              username: `test_user_${Math.floor(Math.random() * 10000)}`,
              publicKey: "test_public_key",
              privateKey: "test_private_key"
            })
          });
          
          console.log("Create response:", createResponse.status, createResponse.statusText);
          
          if (createResponse.ok) {
            const newUser = await createResponse.json();
            console.log("New user created:", newUser);
            setUsername(newUser.username);
          } else {
            setError("Failed to create user");
          }
        }
      } catch (err) {
        console.error("Error:", err);
        setError("Could not connect to server");
      } finally {
        setLoading(false);
      }
    }
    
    fetchUser();
  }, []);
  
  // Show loading state
  if (loading) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-gray-900 text-white p-4">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mb-4"></div>
        <p>Loading...</p>
      </div>
    );
  }
  
  // Show error state
  if (error) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-gray-900 text-white p-4">
        <div className="bg-gray-800 p-6 rounded-lg shadow-lg max-w-md w-full text-center">
          <h2 className="text-xl font-bold text-red-500 mb-4">Error</h2>
          <p className="mb-4">{error}</p>
          <button 
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
            onClick={() => window.location.reload()}
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }
  
  // Show main app
  return (
    <div className="h-screen flex flex-col items-center justify-center bg-gray-900 text-white p-4">
      <h1 className="text-3xl font-bold mb-4">Secure Messaging App</h1>
      <p className="mb-8 text-gray-300">A minimal test version</p>
      
      <div className="bg-gray-800 p-6 rounded-lg shadow-lg w-full max-w-md">
        <h2 className="text-xl font-semibold mb-4">Status</h2>
        <p className="mb-2">Connection to server: <span className="text-green-400">Working</span></p>
        <p>Logged in as: <span className="font-medium">{username}</span></p>
        
        <button 
          className="mt-6 w-full py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
          onClick={() => console.log('Current user:', username)}
        >
          Log to Console
        </button>
      </div>
    </div>
  );
}

export default SimpleApp;