import React, { useState, useEffect } from 'react';

interface User {
  id: number;
  username: string;
  publicKey: string;
  privateKey: string;
}

interface Contact {
  id: number;
  userId: number;
  name: string;
  publicKey: string;
}

interface Message {
  id: number;
  senderId: number;
  receiverId: number;
  content: string;
  encryptedContent: string;
  transactionHash?: string;
  blockConfirmations?: number;
  verified?: boolean;
  createdAt: string;
}

interface Transaction {
  id: string;
  messageId: number;
  hash: string;
  blockId?: number;
  blockHash?: string;
  timestamp: number;
  status: 'pending' | 'confirmed' | 'failed';
  confirmations: number;
}

function RebuildApp() {
  const [user, setUser] = useState<User | null>(null);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [pendingTransactions, setPendingTransactions] = useState<Transaction[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [isAddContactModalOpen, setIsAddContactModalOpen] = useState(false);
  const [isBlockchainInfoModalOpen, setIsBlockchainInfoModalOpen] = useState(false);
  const [pendingMessages, setPendingMessages] = useState(0);
  
  // Initialize app on load
  useEffect(() => {
    async function initializeApp() {
      try {
        console.log("App: Initializing...");
        
        // Try to get existing user
        const response = await fetch("/api/users/current");
        
        if (response.ok) {
          const userData = await response.json();
          console.log("User data:", userData);
          setUser(userData);
        } else {
          console.log("No user found, creating a new one...");
          
          // Create a test user
          const randomUsername = `user_${Math.floor(Math.random() * 10000)}`;
          const createResponse = await fetch("/api/users", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              username: randomUsername,
              publicKey: "test_public_key",
              privateKey: "test_private_key"
            })
          });
          
          if (createResponse.ok) {
            const newUser = await createResponse.json();
            console.log("New user created:", newUser);
            setUser(newUser);
            
            // Create a test contact for the new user
            await createTestContact(newUser.id);
          } else {
            setError("Failed to create user");
          }
        }
        
        // Fetch contacts
        await fetchContacts();
        
        // Get pending transactions
        await fetchPendingTransactions();
      } catch (err) {
        console.error("Error:", err);
        setError("Could not connect to server");
      } finally {
        setLoading(false);
      }
    }
    
    initializeApp();
    
    // Set up polling for updates
    const pollInterval = setInterval(() => {
      if (selectedContact) {
        fetchMessages(selectedContact.id);
      }
      fetchPendingTransactions();
    }, 5000);
    
    return () => clearInterval(pollInterval);
  }, []);
  
  // Fetch contacts
  async function fetchContacts() {
    try {
      const response = await fetch("/api/contacts");
      if (response.ok) {
        const contactsData = await response.json();
        console.log("Contacts:", contactsData);
        setContacts(contactsData);
      }
    } catch (err) {
      console.error("Error fetching contacts:", err);
    }
  }
  
  // Create a test contact
  async function createTestContact(userId: number) {
    try {
      const response = await fetch("/api/contacts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          name: `Contact_${Math.floor(Math.random() * 1000)}`,
          publicKey: "test_contact_public_key"
        })
      });
      
      if (response.ok) {
        console.log("Test contact created");
        await fetchContacts();
      }
    } catch (err) {
      console.error("Error creating test contact:", err);
    }
  }
  
  // Fetch messages for selected contact
  async function fetchMessages(contactId: number) {
    try {
      const response = await fetch(`/api/messages/${contactId}`);
      if (response.ok) {
        const messagesData = await response.json();
        setMessages(messagesData);
      }
    } catch (err) {
      console.error("Error fetching messages:", err);
    }
  }
  
  // Update messages when selected contact changes
  useEffect(() => {
    if (selectedContact) {
      fetchMessages(selectedContact.id);
    }
  }, [selectedContact]);
  
  // Fetch pending blockchain transactions
  async function fetchPendingTransactions() {
    try {
      const response = await fetch('/api/blockchain/transactions/pending');
      if (response.ok) {
        const transactions = await response.json();
        setPendingTransactions(transactions);
      }
    } catch (err) {
      console.error("Error fetching pending transactions:", err);
    }
  }
  
  // Update pending messages count
  useEffect(() => {
    setPendingMessages(pendingTransactions.length);
  }, [pendingTransactions]);
  
  // Send a message
  async function sendMessage() {
    if (!user || !selectedContact || !newMessage.trim()) return;
    
    try {
      const response = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          senderId: user.id,
          receiverId: selectedContact.id,
          content: newMessage
        })
      });
      
      if (response.ok) {
        console.log("Message sent!");
        setNewMessage("");
        fetchMessages(selectedContact.id);
        fetchPendingTransactions();
      }
    } catch (err) {
      console.error("Error sending message:", err);
    }
  }
  
  // Add a new contact
  async function addContact(name: string, publicKey: string) {
    if (!user) return;
    
    try {
      const response = await fetch("/api/contacts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          name,
          publicKey
        })
      });
      
      if (response.ok) {
        console.log("Contact added!");
        fetchContacts();
        setIsAddContactModalOpen(false);
      }
    } catch (err) {
      console.error("Error adding contact:", err);
    }
  }
  
  // Show loading state
  if (loading) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-gray-900 text-white p-4">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mb-4"></div>
        <p>Loading secure messaging platform...</p>
      </div>
    );
  }
  
  // Show error state
  if (error) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-gray-900 text-white p-4">
        <div className="bg-gray-800 p-6 rounded-lg shadow-lg max-w-md w-full text-center">
          <h2 className="text-xl font-bold text-red-500 mb-4">Error</h2>
          <p className="mb-4">{error}</p>
          <button 
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
            onClick={() => window.location.reload()}
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }
  
  // Main application UI
  return (
    <div className="h-screen flex flex-col bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <h1 className="text-xl font-bold">Secure Messaging</h1>
            {pendingMessages > 0 && (
              <button
                onClick={() => setIsBlockchainInfoModalOpen(true)}
                className="bg-yellow-600 text-xs px-2 py-1 rounded-full"
              >
                {pendingMessages} pending
              </button>
            )}
          </div>
          {user && (
            <div 
              className="text-sm bg-gray-700 px-3 py-1 rounded flex items-center gap-2 cursor-pointer group relative"
              onClick={() => {
                // Copy public key to clipboard
                navigator.clipboard.writeText(user.publicKey);
                alert("Public key copied to clipboard!");
              }}
              title="Click to copy your public key"
            >
              <span>{user.username}</span>
              <span className="text-xs text-gray-400">ID: {user.id}</span>
              <span className="hidden group-hover:inline text-xs text-blue-400 ml-1">(Copy Key)</span>
            </div>
          )}
        </div>
      </header>
      
      {/* Main content */}
      <main className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <div className="w-64 bg-gray-800 border-r border-gray-700 flex flex-col">
          <div className="p-4 border-b border-gray-700">
            <h2 className="font-medium mb-2">Contacts</h2>
            <button 
              className="w-full py-2 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 transition"
              onClick={() => setIsAddContactModalOpen(true)}
            >
              Add Contact
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-2">
            {contacts.length === 0 ? (
              <div className="text-center text-gray-500 py-4">
                No contacts found
              </div>
            ) : (
              <ul>
                {contacts.map(contact => (
                  <li 
                    key={contact.id}
                    className={`px-3 py-2 rounded cursor-pointer ${selectedContact?.id === contact.id ? 'bg-blue-600' : 'hover:bg-gray-700'}`}
                  >
                    <div 
                      className="flex flex-col cursor-pointer"
                      onClick={() => setSelectedContact(contact)}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{contact.name}</span>
                        <span className="text-xs text-gray-400">ID: {contact.id}</span>
                      </div>
                      <div className="flex items-center mt-1 text-xs">
                        <span className="text-gray-400 truncate max-w-[140px]">{contact.publicKey.substring(0, 16)}...</span>
                        <button
                          className="ml-2 text-blue-400 hover:text-blue-300"
                          onClick={(e) => {
                            e.stopPropagation();
                            navigator.clipboard.writeText(contact.publicKey);
                            alert(`Copied ${contact.name}'s public key!`);
                          }}
                          title="Copy public key"
                        >
                          Copy
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
        
        {/* Chat area */}
        <div className="flex-1 flex flex-col">
          {selectedContact ? (
            <>
              {/* Chat header */}
              <div className="p-4 border-b border-gray-700 flex items-center justify-between">
                <div>
                  <div className="font-medium flex items-center">
                    {selectedContact.name}
                    <span className="text-xs text-gray-400 ml-2">ID: {selectedContact.id}</span>
                  </div>
                  <div className="text-xs text-gray-400 mt-1 flex items-center">
                    <span className="truncate max-w-[200px]">{selectedContact.publicKey}</span>
                    <button
                      className="ml-2 text-blue-400 hover:text-blue-300"
                      onClick={() => {
                        navigator.clipboard.writeText(selectedContact.publicKey);
                        alert(`Copied ${selectedContact.name}'s public key!`);
                      }}
                    >
                      Copy
                    </button>
                  </div>
                </div>
                <button
                  className="text-xs bg-gray-700 px-2 py-1 rounded hover:bg-gray-600"
                  onClick={() => setIsBlockchainInfoModalOpen(true)}
                >
                  Blockchain Info
                </button>
              </div>
              
              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.length === 0 ? (
                  <div className="text-center text-gray-500 py-4">
                    No messages yet. Start the conversation!
                  </div>
                ) : (
                  messages.map(message => (
                    <div 
                      key={message.id}
                      className={`max-w-xs p-3 rounded-lg ${message.senderId === user?.id ? 'ml-auto bg-blue-600' : 'bg-gray-700'}`}
                    >
                      <p>{message.content}</p>
                      <div className="text-xs text-gray-400 mt-1 flex justify-between">
                        <span>{new Date(message.createdAt).toLocaleTimeString()}</span>
                        {message.transactionHash && (
                          <span className={message.verified ? 'text-green-400' : ''}>
                            {message.verified ? '✓ Verified' : `${message.blockConfirmations || 0} confirms`}
                          </span>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
              
              {/* Message input */}
              <div className="p-4 border-t border-gray-700 flex">
                <input
                  type="text"
                  className="flex-1 bg-gray-700 text-white rounded-l px-4 py-2 focus:outline-none"
                  placeholder="Type a message..."
                  value={newMessage}
                  onChange={e => setNewMessage(e.target.value)}
                  onKeyPress={e => e.key === 'Enter' && sendMessage()}
                />
                <button 
                  className="bg-blue-600 text-white rounded-r px-4 py-2 hover:bg-blue-700 transition"
                  onClick={sendMessage}
                >
                  Send
                </button>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-gray-500">
              Select a contact to start messaging
            </div>
          )}
        </div>
      </main>
      
      {/* Add Contact Modal */}
      {isAddContactModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4">
          <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Add New Contact</h2>
              <button 
                className="text-gray-400 hover:text-white"
                onClick={() => setIsAddContactModalOpen(false)}
              >
                ✕
              </button>
            </div>
            
            {/* Your public key section for sharing */}
            {user && (
              <div className="mb-6 p-3 bg-gray-700 rounded">
                <label className="block text-sm mb-1 font-medium">Your Public Key (Share This)</label>
                <div className="flex">
                  <input 
                    type="text" 
                    className="flex-1 bg-gray-600 text-white rounded-l px-3 py-2 text-xs"
                    value={user.publicKey}
                    readOnly
                  />
                  <button
                    className="bg-blue-600 text-white rounded-r px-3 py-2 hover:bg-blue-700 text-xs"
                    onClick={() => {
                      navigator.clipboard.writeText(user.publicKey);
                      alert("Your public key copied to clipboard. Share this with others so they can add you as a contact.");
                    }}
                  >
                    Copy
                  </button>
                </div>
                <p className="text-xs text-gray-400 mt-1">Share this with others so they can add you as a contact</p>
              </div>
            )}
            
            <div className="mb-4">
              <label className="block text-sm mb-1">Name</label>
              <input 
                type="text" 
                className="w-full bg-gray-700 text-white rounded px-3 py-2"
                id="contactName"
                placeholder="Contact name"
              />
            </div>
            
            <div className="mb-6">
              <label className="block text-sm mb-1">Public Key</label>
              <input 
                type="text" 
                className="w-full bg-gray-700 text-white rounded px-3 py-2"
                id="publicKey"
                placeholder="Contact's public key"
              />
            </div>
            
            <div className="flex justify-end space-x-3">
              <button
                className="px-4 py-2 bg-gray-700 rounded hover:bg-gray-600"
                onClick={() => setIsAddContactModalOpen(false)}
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 bg-blue-600 rounded hover:bg-blue-700"
                onClick={() => {
                  const nameEl = document.getElementById('contactName') as HTMLInputElement;
                  const keyEl = document.getElementById('publicKey') as HTMLInputElement;
                  if (nameEl && keyEl && nameEl.value && keyEl.value) {
                    addContact(nameEl.value, keyEl.value);
                  }
                }}
              >
                Add Contact
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Blockchain Info Modal */}
      {isBlockchainInfoModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4">
          <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Blockchain Transactions</h2>
              <button 
                className="text-gray-400 hover:text-white"
                onClick={() => setIsBlockchainInfoModalOpen(false)}
              >
                ✕
              </button>
            </div>
            
            {pendingTransactions.length === 0 ? (
              <div className="text-center text-gray-500 py-6">
                No pending transactions
              </div>
            ) : (
              <div className="space-y-4">
                {pendingTransactions.map(tx => (
                  <div key={tx.id} className="bg-gray-700 p-3 rounded">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="font-medium">Message ID: {tx.messageId}</span>
                      <span className={`px-2 py-0.5 rounded text-xs ${
                        tx.status === 'confirmed' ? 'bg-green-800' : 
                        tx.status === 'failed' ? 'bg-red-800' : 'bg-yellow-800'
                      }`}>
                        {tx.status}
                      </span>
                    </div>
                    <div className="text-xs text-gray-400 break-all mb-1">
                      Hash: {tx.hash.substring(0, 20)}...
                    </div>
                    <div className="flex justify-between text-xs">
                      <span>
                        {new Date(tx.timestamp).toLocaleString()}
                      </span>
                      <span>
                        {tx.confirmations} confirmations
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default RebuildApp;