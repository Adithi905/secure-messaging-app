import { useState, useRef, useEffect } from "react";
import { Contact, Message, User } from "@shared/schema";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { formatPublicKeyShort } from "@/lib/crypto";

interface ChatPanelProps {
  currentUser: User | null;
  currentContact: Contact | null;
  messages: Message[];
  pendingMessages: number;
  onSendMessage: (content: string) => void;
  onShowBlockchainInfo: () => void;
  isLoading: boolean;
}

export default function ChatPanel({
  currentUser,
  currentContact,
  messages,
  pendingMessages,
  onSendMessage,
  onShowBlockchainInfo,
  isLoading
}: ChatPanelProps) {
  const [newMessage, setNewMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (newMessage.trim() && onSendMessage) {
      onSendMessage(newMessage.trim());
      setNewMessage("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Format timestamp to readable time
  const formatTime = (timestamp: Date) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  // Group messages by date
  const groupMessagesByDate = () => {
    const groups: { date: string; messages: Message[] }[] = [];
    
    messages.forEach(message => {
      const messageDate = new Date(message.createdAt).toLocaleDateString();
      const group = groups.find(g => g.date === messageDate);
      
      if (group) {
        group.messages.push(message);
      } else {
        groups.push({ date: messageDate, messages: [message] });
      }
    });
    
    return groups;
  };

  // Format date for separator
  const formatDateSeparator = (dateString: string) => {
    const messageDate = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (messageDate.toDateString() === today.toDateString()) {
      return "Today";
    } else if (messageDate.toDateString() === yesterday.toDateString()) {
      return "Yesterday";
    } else {
      return messageDate.toLocaleDateString(undefined, { 
        weekday: 'long', 
        month: 'short', 
        day: 'numeric' 
      });
    }
  };

  // Get initials for contact avatar
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  // Get avatar color
  const getContactColor = (id: number) => {
    const colors = [
      'bg-blue-600',
      'bg-indigo-600',
      'bg-purple-600',
      'bg-pink-600',
      'bg-red-600',
      'bg-amber-600',
      'bg-emerald-700',
      'bg-teal-600',
    ];
    return colors[id % colors.length];
  };

  // If no contact is selected
  if (!currentContact) {
    return (
      <section className="flex-1 flex flex-col items-center justify-center bg-[#121212] text-gray-400">
        <div className="max-w-md text-center p-8">
          <i className="ri-chat-3-line text-5xl mb-4"></i>
          <h2 className="text-xl font-semibold text-white mb-2">Select a Contact</h2>
          <p>Choose a contact from the list to start a secure, encrypted conversation</p>
        </div>
      </section>
    );
  }

  const messageGroups = groupMessagesByDate();

  return (
    <section className="flex-1 flex flex-col">
      {/* Chat Header */}
      <div className="bg-[#1E1E1E] border-b border-[#333333] p-4 flex items-center justify-between">
        <div className="flex items-center">
          <div className={`w-10 h-10 rounded-full ${getContactColor(currentContact.id)} flex items-center justify-center text-white font-medium`}>
            {getInitials(currentContact.name)}
          </div>
          <div className="ml-3">
            <h2 className="font-medium">{currentContact.name}</h2>
            <div className="flex items-center text-sm text-gray-400">
              <i className="ri-key-2-line mr-1 text-[#10B981]"></i>
              <span className="text-xs truncate font-mono">
                {formatPublicKeyShort(currentContact.publicKey)}
              </span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <button 
            className="p-2 rounded-full hover:bg-[#2A2A2A] text-[#10B981]" 
            title="Verified Contact"
          >
            <i className="ri-shield-check-fill"></i>
          </button>
          <button 
            onClick={onShowBlockchainInfo}
            className="p-2 rounded-full hover:bg-[#2A2A2A]" 
            title="View Blockchain Info"
          >
            <i className="ri-link"></i>
          </button>
          <button 
            className="p-2 rounded-full hover:bg-[#2A2A2A]" 
            title="Chat Options"
          >
            <i className="ri-more-2-fill"></i>
          </button>
        </div>
      </div>
      
      {/* Transaction Status Banner */}
      {pendingMessages > 0 && (
        <div className="bg-[#2A2A2A] border-b border-[#333333] px-4 py-2 flex items-center justify-between">
          <div className="flex items-center text-sm text-[#F59E0B]">
            <i className="ri-time-line mr-2"></i>
            <span>{pendingMessages} message{pendingMessages !== 1 ? 's' : ''} pending blockchain confirmation</span>
          </div>
          <button 
            onClick={onShowBlockchainInfo}
            className="text-[#3B82F6] text-sm hover:underline"
          >
            View Details
          </button>
        </div>
      )}
      
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 scrollbar-thin">
        {isLoading ? (
          // Loading state
          <div className="space-y-4 py-4">
            <div className="flex justify-center my-4">
              <Skeleton className="h-6 w-24 rounded-full" />
            </div>
            {[1, 2, 3].map(i => (
              <div key={i} className={`flex ${i % 2 === 0 ? 'justify-end' : 'justify-start'}`}>
                <Skeleton className={`h-20 ${i % 2 === 0 ? 'w-64 ml-12' : 'w-48 mr-12'} rounded-lg`} />
              </div>
            ))}
          </div>
        ) : messages.length > 0 ? (
          // Messages content
          messageGroups.map(group => (
            <div key={group.date}>
              {/* Date Separator */}
              <div className="flex items-center justify-center my-4">
                <div className="bg-[#1E1E1E] text-gray-400 text-xs px-3 py-1 rounded-full">
                  {formatDateSeparator(group.date)}
                </div>
              </div>
              
              {/* Messages */}
              {group.messages.map(message => {
                const isSent = currentUser && message.senderId === currentUser.id;
                
                return (
                  <div
                    key={message.id}
                    className={`message-bubble ${isSent ? 'sent' : 'received'}`}
                    style={{
                      maxWidth: '80%',
                      position: 'relative',
                      borderRadius: '0.5rem',
                      padding: '0.75rem',
                      margin: '0.5rem 0',
                      backgroundColor: isSent ? '#3B82F6' : '#1E1E1E',
                      marginLeft: isSent ? 'auto' : '0',
                      marginRight: isSent ? '0' : 'auto',
                      borderBottomRightRadius: isSent ? '0' : '0.5rem',
                      borderBottomLeftRadius: isSent ? '0.5rem' : '0',
                    }}
                  >
                    <p className="mb-1">{message.content}</p>
                    <div className="text-xs text-gray-300">
                      {formatTime(message.createdAt)}
                    </div>
                    
                    {/* Encryption badge */}
                    <div 
                      className="absolute -bottom-6 text-xs flex items-center gap-1 opacity-80"
                      style={{
                        [isSent ? 'right' : 'left']: 0,
                      }}
                    >
                      {message.verified ? (
                        <>
                          <i className="ri-lock-fill text-[#10B981]"></i>
                          <span className="text-[#10B981]">Verified & Encrypted</span>
                        </>
                      ) : message.blockConfirmations > 0 ? (
                        <>
                          <i className="ri-shield-check-fill text-[#10B981]"></i>
                          <span className="text-[#10B981]">Encrypted</span>
                        </>
                      ) : (
                        <>
                          <i className="ri-time-line text-[#F59E0B]"></i>
                          <span className="text-[#F59E0B]">
                            {isSent ? 'Pending Confirmation' : 'Pending Verification'}
                          </span>
                        </>
                      )}
                    </div>
                    
                    {/* Transaction Hash (if available) */}
                    {message.transactionHash && (
                      <div className="mt-2 pt-2 border-t border-blue-400/30 text-xs font-mono text-gray-300 break-all">
                        <div className="text-gray-400 mb-1">Transaction Hash:</div>
                        {message.transactionHash}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))
        ) : (
          // No messages
          <div className="h-full flex flex-col items-center justify-center text-gray-400 p-8">
            <i className="ri-lock-2-fill text-4xl mb-3"></i>
            <h3 className="text-lg font-medium text-white mb-1">End-to-End Encrypted Chat</h3>
            <p className="text-center max-w-md">
              Messages sent here are secured with encryption and verified on the blockchain
            </p>
          </div>
        )}
        
        {/* Element to scroll to bottom */}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Message Input */}
      <div className="p-4 border-t border-[#333333] bg-[#1E1E1E]">
        <div className="relative">
          <Textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type secure message..."
            className="w-full bg-[#121212] border border-[#333333] rounded-lg pl-4 pr-10 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-[#3B82F6] resize-none h-12"
          />
          
          <div className="absolute right-0 top-0 h-full flex items-center pr-2">
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-gray-400 hover:text-white" 
              title="Attach File"
            >
              <i className="ri-attachment-2"></i>
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-[#3B82F6] hover:text-blue-400" 
              title="Send Message"
              onClick={handleSendMessage}
              disabled={!newMessage.trim()}
            >
              <i className="ri-send-plane-fill"></i>
            </Button>
          </div>
        </div>
        
        <div className="flex items-center justify-between mt-2 text-xs text-gray-400">
          <div className="flex items-center">
            <i className="ri-lock-fill text-[#10B981] mr-1"></i>
            <span>End-to-end encrypted</span>
          </div>
          <div className="flex items-center">
            <i className="ri-link mr-1"></i>
            <span>Will be stored on blockchain</span>
          </div>
        </div>
      </div>
    </section>
  );
}
