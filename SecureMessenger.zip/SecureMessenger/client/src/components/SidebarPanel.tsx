import { useState } from "react";
import { Contact, User } from "@shared/schema";
import { formatPublicKeyShort } from "@/lib/crypto";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";

interface SidebarPanelProps {
  currentUser: User | null;
  contacts: Contact[];
  selectedContact: Contact | null;
  onSelectContact: (contact: Contact) => void;
  onAddContactClick: () => void;
  isLoading: boolean;
}

export default function SidebarPanel({
  currentUser,
  contacts,
  selectedContact,
  onSelectContact,
  onAddContactClick,
  isLoading
}: SidebarPanelProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [isPrivateKeyVisible, setIsPrivateKeyVisible] = useState(false);

  const handleGenerateNewKeys = async () => {
    // This would be implemented with a call to regenerate keys
    console.log("Regenerate keys");
  };

  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key);
  };

  // Filter contacts based on search term
  const filteredContacts = contacts.filter(contact => 
    contact.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Function to get a contact's initial letters
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  // Randomly assign a color to a contact
  const getContactColor = (id: number) => {
    const colors = [
      'bg-blue-600',
      'bg-indigo-600',
      'bg-purple-600',
      'bg-pink-600',
      'bg-red-600',
      'bg-amber-600',
      'bg-emerald-700',
      'bg-teal-600',
    ];
    return colors[id % colors.length];
  };

  return (
    <aside className="w-full md:w-80 flex-shrink-0 border-r border-[#333333] bg-[#1E1E1E] flex flex-col">
      {/* User Key Management Panel */}
      <div className="p-4 border-b border-[#333333]">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-medium">Your Keys</h2>
          <button 
            onClick={handleGenerateNewKeys}
            className="text-sm text-[#3B82F6] hover:underline flex items-center"
          >
            <i className="ri-refresh-line mr-1"></i> Regenerate
          </button>
        </div>
        
        {currentUser ? (
          <div className="bg-[#121212] rounded-lg p-3 text-xs font-mono text-gray-300 relative overflow-hidden">
            <div className="flex justify-between mb-1">
              <span className="text-gray-400">Public Key</span>
              <button 
                onClick={() => handleCopyKey(currentUser.publicKey)}
                className="text-[#3B82F6] hover:text-blue-400"
              >
                <i className="ri-file-copy-line"></i>
              </button>
            </div>
            <div className="truncate">
              {formatPublicKeyShort(currentUser.publicKey)}
            </div>
            
            <div className="flex justify-between mb-1 mt-3">
              <span className="text-gray-400">Private Key</span>
              <div className="flex space-x-2">
                <button 
                  onClick={() => setIsPrivateKeyVisible(!isPrivateKeyVisible)}
                  className="text-[#3B82F6] hover:text-blue-400"
                >
                  <i className={`ri-${isPrivateKeyVisible ? 'eye-off' : 'eye'}-line`}></i>
                </button>
                <button 
                  onClick={() => handleCopyKey(currentUser.privateKey)}
                  className="text-[#3B82F6] hover:text-blue-400"
                >
                  <i className="ri-file-copy-line"></i>
                </button>
              </div>
            </div>
            <div className="truncate">
              {isPrivateKeyVisible 
                ? formatPublicKeyShort(currentUser.privateKey) 
                : '•••••••••••••••••••••••••••••••••••••••••••••'}
            </div>
          </div>
        ) : (
          <div className="space-y-2">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-1/2" />
          </div>
        )}
        
        <div className="flex justify-between mt-4 text-sm">
          <div className="text-[#10B981] flex items-center">
            <i className="ri-shield-check-fill mr-1"></i>
            <span>End-to-End Encrypted</span>
          </div>
          <div className="text-[#F59E0B] flex items-center">
            <i className="ri-link mr-1"></i>
            <span>Blockchain Secured</span>
          </div>
        </div>
      </div>
      
      {/* Contact Search */}
      <div className="p-4 border-b border-[#333333]">
        <div className="relative">
          <Input
            type="text"
            placeholder="Search contacts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#121212] border border-[#333333] rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#3B82F6]"
          />
          <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
        </div>
      </div>
      
      {/* Contact List */}
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        <h3 className="px-4 pt-4 pb-2 text-xs uppercase text-gray-400 font-semibold">Recent Contacts</h3>
        
        {isLoading ? (
          // Loading state
          <div className="space-y-3 px-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center p-2">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="ml-3 space-y-2 flex-1">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-3 w-32" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredContacts.length > 0 ? (
          // Contact list
          filteredContacts.map((contact) => (
            <div 
              key={contact.id} 
              className="px-3 cursor-pointer"
              onClick={() => onSelectContact(contact)}
            >
              <div className={`flex items-center p-2 rounded-lg hover:bg-[#2A2A2A] ${
                selectedContact?.id === contact.id ? 'bg-[#2A2A2A]' : ''
              } border-l-4 ${
                selectedContact?.id === contact.id ? 'border-[#10B981]' : 'border-[#1E1E1E]'
              }`}>
                <div className={`w-10 h-10 rounded-full ${getContactColor(contact.id)} flex items-center justify-center text-white font-medium flex-shrink-0`}>
                  {getInitials(contact.name)}
                </div>
                <div className="ml-3 flex-1 min-w-0">
                  <div className="flex justify-between">
                    <p className="font-medium truncate">{contact.name}</p>
                    <span className="text-xs text-gray-400">Online</span>
                  </div>
                  <div className="flex items-center">
                    <i className="ri-lock-fill text-[#10B981] text-xs mr-1"></i>
                    <p className="text-sm text-gray-300 truncate font-mono">
                      {formatPublicKeyShort(contact.publicKey)}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          // No contacts or no search results
          <div className="px-4 py-8 text-center text-gray-400">
            <i className="ri-user-search-line text-3xl mb-2"></i>
            <p>{searchTerm ? 'No contacts match your search' : 'No contacts yet'}</p>
            <p className="text-sm mt-1">Add contacts to start messaging</p>
          </div>
        )}
        
        <h3 className="px-4 pt-4 pb-2 text-xs uppercase text-gray-400 font-semibold">Public Channels</h3>
        
        {/* Public channels - future feature */}
        <div className="px-4 py-3 text-center text-gray-400 text-sm">
          <p>Public channels coming soon</p>
        </div>
      </div>
      
      {/* Add Contact Button */}
      <div className="p-4 border-t border-[#333333]">
        <button 
          onClick={onAddContactClick}
          className="w-full bg-[#3B82F6] text-white py-2 px-4 rounded-lg flex items-center justify-center hover:bg-blue-600 transition"
        >
          <i className="ri-user-add-line mr-2"></i>
          Add New Contact
        </button>
      </div>
    </aside>
  );
}
