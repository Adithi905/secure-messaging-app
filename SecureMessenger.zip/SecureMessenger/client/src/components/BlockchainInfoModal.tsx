import { Dialog, DialogContent, DialogTitle, DialogHeader, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Transaction } from "@/lib/blockchain";

interface BlockchainInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  pendingTransactions: Transaction[];
}

export default function BlockchainInfoModal({ 
  isOpen, 
  onClose,
  pendingTransactions = []
}: BlockchainInfoModalProps) {
  // Function to format time ago
  const formatTimeAgo = (timestamp: number) => {
    const now = new Date();
    const secondsAgo = Math.floor((now.getTime() - timestamp) / 1000);
    
    if (secondsAgo < 60) return `${secondsAgo} second${secondsAgo !== 1 ? 's' : ''} ago`;
    if (secondsAgo < 3600) return `${Math.floor(secondsAgo / 60)} minute${Math.floor(secondsAgo / 60) !== 1 ? 's' : ''} ago`;
    if (secondsAgo < 86400) return `${Math.floor(secondsAgo / 3600)} hour${Math.floor(secondsAgo / 3600) !== 1 ? 's' : ''} ago`;
    return `${Math.floor(secondsAgo / 86400)} day${Math.floor(secondsAgo / 86400) !== 1 ? 's' : ''} ago`;
  };

  // Group transactions by status
  const confirmedTransactions = pendingTransactions.filter(tx => tx.status === 'confirmed');
  const pendingTxs = pendingTransactions.filter(tx => tx.status === 'pending');
  const failedTransactions = pendingTransactions.filter(tx => tx.status === 'failed');

  // Calculate stats
  const totalMessages = confirmedTransactions.length + pendingTxs.length + failedTransactions.length;
  const messagesOnBlockchain = confirmedTransactions.length;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="bg-[#1E1E1E] text-white border-[#333333] sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">Blockchain Transactions</DialogTitle>
        </DialogHeader>
        
        <div className="py-2 space-y-5">
          <div className="border border-[#333333] rounded-lg">
            <div className="border-b border-[#333333] p-3 bg-[#2A2A2A]">
              <h3 className="font-medium">Conversation Status</h3>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-gray-400 mb-1">Total Messages</div>
                  <div className="font-medium">{totalMessages}</div>
                </div>
                <div>
                  <div className="text-gray-400 mb-1">Messages on Blockchain</div>
                  <div className="font-medium">{messagesOnBlockchain}</div>
                </div>
                <div>
                  <div className="text-gray-400 mb-1">Pending Confirmation</div>
                  <div className="font-medium text-[#F59E0B]">{pendingTxs.length}</div>
                </div>
                <div>
                  <div className="text-gray-400 mb-1">Failed Transactions</div>
                  <div className="font-medium text-[#EF4444]">{failedTransactions.length}</div>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="font-medium mb-3">Recent Transactions</h3>
            
            {pendingTransactions.length > 0 ? (
              <div className="space-y-3 mb-5">
                {/* Pending transactions first */}
                {pendingTxs.map(tx => (
                  <div key={tx.id} className="border border-[#333333] rounded-lg overflow-hidden">
                    <div className="bg-[#2A2A2A] p-3 flex justify-between items-center">
                      <div className="flex items-center">
                        <i className="ri-time-line text-[#F59E0B] mr-2"></i>
                        <span className="font-medium">Pending</span>
                      </div>
                      <div className="text-xs text-gray-400">
                        {formatTimeAgo(tx.timestamp)}
                      </div>
                    </div>
                    <div className="p-3">
                      <div className="text-xs font-mono mb-2 break-all">
                        <span className="text-gray-400">TX Hash: </span>
                        {tx.hash}
                      </div>
                      <div className="flex justify-between text-sm">
                        <div>
                          <span className="text-gray-400">Block: </span>
                          <span>Pending</span>
                        </div>
                        <div>
                          <span className="text-gray-400">Confirmations: </span>
                          <span>{tx.confirmations}/3</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {/* Confirmed transactions */}
                {confirmedTransactions.map(tx => (
                  <div key={tx.id} className="border border-[#333333] rounded-lg overflow-hidden">
                    <div className="bg-[#2A2A2A] p-3 flex justify-between items-center">
                      <div className="flex items-center">
                        <i className="ri-checkbox-circle-fill text-[#10B981] mr-2"></i>
                        <span className="font-medium">Confirmed</span>
                      </div>
                      <div className="text-xs text-gray-400">
                        {formatTimeAgo(tx.timestamp)}
                      </div>
                    </div>
                    <div className="p-3">
                      <div className="text-xs font-mono mb-2 break-all">
                        <span className="text-gray-400">TX Hash: </span>
                        {tx.hash}
                      </div>
                      <div className="flex justify-between text-sm">
                        <div>
                          <span className="text-gray-400">Block: </span>
                          <span>#{tx.blockId || 'Unknown'}</span>
                        </div>
                        <div>
                          <span className="text-gray-400">Confirmations: </span>
                          <span className="text-[#10B981]">{tx.confirmations}/3</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {/* Failed transactions */}
                {failedTransactions.map(tx => (
                  <div key={tx.id} className="border border-[#333333] rounded-lg overflow-hidden">
                    <div className="bg-[#2A2A2A] p-3 flex justify-between items-center">
                      <div className="flex items-center">
                        <i className="ri-close-circle-fill text-[#EF4444] mr-2"></i>
                        <span className="font-medium">Failed</span>
                      </div>
                      <div className="text-xs text-gray-400">
                        {formatTimeAgo(tx.timestamp)}
                      </div>
                    </div>
                    <div className="p-3">
                      <div className="text-xs font-mono mb-2 break-all">
                        <span className="text-gray-400">TX Hash: </span>
                        {tx.hash}
                      </div>
                      <div className="flex justify-between text-sm">
                        <div>
                          <span className="text-gray-400">Status: </span>
                          <span className="text-[#EF4444]">Transaction Failed</span>
                        </div>
                        <div>
                          <span className="text-gray-400">Reason: </span>
                          <span>Network Error</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-400">
                <i className="ri-link-m text-4xl mb-2"></i>
                <p>No blockchain transactions yet</p>
                <p className="text-sm mt-1">Messages will be stored on the blockchain when sent</p>
              </div>
            )}
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            onClick={onClose}
            className="bg-[#3B82F6] hover:bg-blue-600 text-white"
          >
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}