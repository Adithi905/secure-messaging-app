import { useState } from "react";
import { Dialog, DialogContent, DialogTitle, DialogHeader, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface AddContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddContact: (name: string, publicKey: string) => void;
}

export default function AddContactModal({ isOpen, onClose, onAddContact }: AddContactModalProps) {
  const [name, setName] = useState("");
  const [publicKey, setPublicKey] = useState("");
  const [errors, setErrors] = useState<{ name?: string; publicKey?: string }>({});

  const handleSubmit = () => {
    // Validate inputs
    const newErrors: { name?: string; publicKey?: string } = {};
    
    if (!name.trim()) {
      newErrors.name = "Contact name is required";
    }
    
    if (!publicKey.trim()) {
      newErrors.publicKey = "Public key is required";
    } else {
      // Basic check if the public key is in valid JSON format
      try {
        JSON.parse(publicKey);
      } catch (e) {
        newErrors.publicKey = "Invalid public key format";
      }
    }
    
    setErrors(newErrors);
    
    // If valid, add contact
    if (Object.keys(newErrors).length === 0) {
      onAddContact(name, publicKey);
      // Reset form
      setName("");
      setPublicKey("");
      setErrors({});
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="bg-[#1E1E1E] text-white border-[#333333] sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">Add New Contact</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="contact-name" className="text-sm font-medium text-gray-300">
              Contact Name
            </Label>
            <Input
              id="contact-name"
              placeholder="Enter name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-[#121212] border-[#333333] focus:ring-[#3B82F6]"
            />
            {errors.name && <p className="text-xs text-red-500">{errors.name}</p>}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="public-key" className="text-sm font-medium text-gray-300">
              Public Key
            </Label>
            <Textarea
              id="public-key"
              placeholder="Paste contact's public key"
              value={publicKey}
              onChange={(e) => setPublicKey(e.target.value)}
              className="h-24 resize-none font-mono bg-[#121212] border-[#333333] focus:ring-[#3B82F6]"
            />
            {errors.publicKey && <p className="text-xs text-red-500">{errors.publicKey}</p>}
            
            <div className="flex items-center mt-2 text-xs text-gray-400">
              <i className="ri-information-line mr-1"></i>
              <span>Public key is required for end-to-end encryption</span>
            </div>
          </div>
        </div>
        
        <DialogFooter className="flex items-center justify-between sm:justify-between gap-2">
          <DialogClose asChild>
            <Button variant="outline" className="border-[#333333] hover:bg-[#2A2A2A] hover:text-white">
              Cancel
            </Button>
          </DialogClose>
          <Button 
            onClick={handleSubmit}
            className="bg-[#3B82F6] hover:bg-blue-600 text-white"
          >
            Add Contact
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
