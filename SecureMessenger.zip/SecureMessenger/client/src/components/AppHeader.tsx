import { User } from "@shared/schema";
import { useState } from "react";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { formatPublicKeyShort } from "@/lib/crypto";

interface AppHeaderProps {
  currentUser: User | null;
}

export default function AppHeader({ currentUser }: AppHeaderProps) {
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'disconnected'>('connected');
  
  return (
    <header className="bg-[#1E1E1E] border-b border-[#333333] py-3 px-4 flex items-center justify-between">
      <div className="flex items-center">
        <i className="ri-lock-2-fill text-[#10B981] text-xl mr-2"></i>
        <h1 className="text-xl font-semibold">Decentralized Secure Messaging</h1>
      </div>
      
      <div className="flex items-center space-x-3">
        <div className={`flex items-center text-${connectionStatus === 'connected' ? '[#10B981]' : '[#EF4444]'} text-sm`}>
          <i className={`${connectionStatus === 'connected' ? 'ri-checkbox-circle-fill' : 'ri-close-circle-fill'} mr-1`}></i>
          <span>{connectionStatus === 'connected' ? 'Connected' : 'Disconnected'}</span>
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="p-2 rounded-full hover:bg-[#2A2A2A]">
              <i className="ri-user-3-line"></i>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {currentUser && (
              <>
                <DropdownMenuItem className="flex flex-col items-start">
                  <span className="font-medium">{currentUser.username}</span>
                  <span className="text-xs text-muted-foreground font-mono">
                    {formatPublicKeyShort(currentUser.publicKey)}
                  </span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
              </>
            )}
            <DropdownMenuItem>
              <i className="ri-settings-3-line mr-2"></i>
              <span>Settings</span>
            </DropdownMenuItem>
            <DropdownMenuItem>
              <i className="ri-shield-keyhole-line mr-2"></i>
              <span>Security</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <i className="ri-logout-box-r-line mr-2"></i>
              <span>Logout</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
