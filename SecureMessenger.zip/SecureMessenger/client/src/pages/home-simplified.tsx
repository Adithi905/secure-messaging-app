import { useContext } from "react";
import { CurrentUserContext } from "@/App";

export default function HomeSimplified() {
  const { currentUser, isLoading } = useContext(CurrentUserContext);
  
  // Debug state helper
  const debugAppState = () => {
    console.log("--- DEBUG APP STATE ---");
    console.log("1. Current User:", currentUser);
    console.log("2. User Loading:", isLoading);
  };
  
  // If loading, show minimal loading state
  if (isLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-gray-900 text-white">
        <div className="flex flex-col items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mb-4"></div>
          <p className="text-lg">Loading secure environment...</p>
          <button 
            onClick={debugAppState}
            className="mt-8 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            Debug (Check Console)
          </button>
        </div>
      </div>
    );
  }
  
  // Simple UI to make sure we're rendering properly
  return (
    <div className="h-screen flex flex-col bg-gray-900 text-white">
      <header className="bg-gray-800 border-b border-gray-700 p-4">
        <h1 className="text-xl font-bold">Secure Messaging Platform</h1>
        {currentUser && (
          <div className="text-sm text-gray-400">
            Logged in as: {currentUser.username}
          </div>
        )}
      </header>
      
      <main className="flex-1 flex items-center justify-center">
        <div className="bg-gray-800 p-8 rounded-lg max-w-md w-full">
          <h2 className="text-2xl font-bold mb-4">Debug Panel</h2>
          
          <div className="mb-6">
            <h3 className="text-lg font-medium mb-2">Application Status</h3>
            <div className="bg-gray-700 p-4 rounded">
              <p>User Loading: {isLoading ? "Yes" : "No"}</p>
              <p>User: {currentUser ? currentUser.username : "Not logged in"}</p>
            </div>
          </div>
          
          <button 
            onClick={debugAppState}
            className="w-full py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            Debug (Check Console)
          </button>
        </div>
      </main>
    </div>
  );
}