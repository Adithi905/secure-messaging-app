import { useState, useEffect } from 'react';

export default function BasicPage() {
  const [username, setUsername] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Simple function to fetch the current user
    async function fetchUser() {
      try {
        console.log("Basic page: attempting to fetch user");
        const response = await fetch("/api/users/current", {
          credentials: "include"
        });

        console.log("API response:", response.status, response.statusText);

        if (response.ok) {
          const user = await response.json();
          console.log("User data:", user);
          setUsername(user.username);
        } else {
          setError("User not found");
        }
      } catch (e) {
        console.error("Error fetching user:", e);
        setError("Failed to load user");
      } finally {
        setIsLoading(false);
      }
    }

    fetchUser();
  }, []);

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-900 text-white">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-2 border-blue-500 border-t-transparent mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-900 text-white">
        <div className="text-center bg-gray-800 p-8 rounded-lg">
          <h1 className="text-xl font-bold text-red-500 mb-4">Error</h1>
          <p>{error}</p>
          <p className="mt-4 text-sm text-gray-400">Check console for details</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex items-center justify-center bg-gray-900 text-white">
      <div className="text-center bg-gray-800 p-8 rounded-lg max-w-md w-full">
        <h1 className="text-2xl font-bold mb-6">Secure Messaging Platform</h1>
        
        <div className="bg-gray-700 p-4 rounded mb-6">
          <p className="text-lg">Welcome, <span className="font-bold">{username}</span></p>
          <p className="text-sm text-gray-400 mt-2">Your account is ready</p>
        </div>
        
        <div className="flex justify-center">
          <button 
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            onClick={() => console.log("Current user:", username)}
          >
            Debug (Check Console)
          </button>
        </div>
      </div>
    </div>
  );
}