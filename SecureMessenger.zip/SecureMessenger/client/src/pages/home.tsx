import { useState, useContext, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { CurrentUserContext } from "@/App";
import AppHeader from "@/components/AppHeader";
import SidebarPanel from "@/components/SidebarPanel";
import ChatPanel from "@/components/ChatPanel";
import AddContactModal from "@/components/AddContactModal";
import BlockchainInfoModal from "@/components/BlockchainInfoModal";
import { Contact, Message } from "@shared/schema";
import { Transaction } from "@/lib/blockchain";
import { apiRequest } from "@/lib/queryClient";

export default function Home() {
  const { currentUser, isLoading } = useContext(CurrentUserContext);
  const [isAddContactModalOpen, setIsAddContactModalOpen] = useState(false);
  const [isBlockchainInfoModalOpen, setIsBlockchainInfoModalOpen] = useState(false);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [pendingMessages, setPendingMessages] = useState<number>(0);

  // Fetch contacts
  const { 
    data: contacts = [] as Contact[],
    isLoading: contactsLoading,
    refetch: refetchContacts
  } = useQuery<Contact[]>({
    queryKey: ['/api/contacts'],
    enabled: !!currentUser,
  });

  // Fetch messages for selected contact
  const {
    data: messages = [] as Message[],
    isLoading: messagesLoading,
    refetch: refetchMessages
  } = useQuery<Message[]>({
    queryKey: ['/api/messages', selectedContact?.id],
    enabled: !!selectedContact,
  });

  // Fetch pending transactions
  const {
    data: pendingTransactions = [] as Transaction[],
    isLoading: pendingTransactionsLoading,
    refetch: refetchPendingTransactions
  } = useQuery<Transaction[]>({
    queryKey: ['/api/blockchain/transactions/pending'],
    enabled: !!currentUser,
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Update pending messages count
  useEffect(() => {
    if (pendingTransactions && Array.isArray(pendingTransactions)) {
      setPendingMessages(pendingTransactions.length);
    } else {
      setPendingMessages(0);
    }
  }, [pendingTransactions]);

  // WebSocket connection temporarily disabled for debugging
  // We'll use interval polling instead of WebSockets for now
  useEffect(() => {
    if (!currentUser) return;
    
    console.log("WebSocket functionality temporarily disabled");
    
    // Set up polling for data refreshes instead of WebSocket
    const pollInterval = setInterval(() => {
      if (selectedContact) {
        // Refresh messages for current contact
        refetchMessages();
      }
      
      // Refresh contacts and pending transactions
      refetchContacts();
      refetchPendingTransactions();
    }, 5000); // Poll every 5 seconds
    
    // Clean up the interval on unmount
    return () => {
      clearInterval(pollInterval);
    };
  }, [currentUser, selectedContact, refetchMessages, refetchContacts, refetchPendingTransactions]);

  // Handler for adding a contact
  const handleAddContact = async (name: string, publicKey: string) => {
    if (!currentUser) return;

    try {
      await apiRequest('POST', '/api/contacts', {
        userId: currentUser.id,
        name,
        publicKey
      });
      
      // Refresh contacts
      refetchContacts();
      
      // Close modal
      setIsAddContactModalOpen(false);
    } catch (error) {
      console.error("Error adding contact:", error);
    }
  };

  // Handler for sending a message
  const handleSendMessage = async (content: string) => {
    if (!currentUser || !selectedContact) return;

    try {
      await apiRequest('POST', '/api/messages', {
        senderId: currentUser.id,
        receiverId: selectedContact.id,
        content
      });
      
      // Refresh messages
      refetchMessages();
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  // Log the component's state for debugging
  useEffect(() => {
    console.log("Home component state:");
    console.log("- currentUser:", currentUser);
    console.log("- isLoading:", isLoading);
    console.log("- contactsLoading:", contactsLoading);
    console.log("- contacts:", contacts);
    console.log("- selectedContact:", selectedContact);
    console.log("- messagesLoading:", messagesLoading);
    console.log("- pendingTransactionsLoading:", pendingTransactionsLoading);
  }, [currentUser, isLoading, contacts, contactsLoading, selectedContact, messagesLoading, pendingTransactionsLoading]);

  // If loading, show minimal loading state
  const debugAppState = () => {
    console.log("--- DEBUG APP STATE ---");
    console.log("1. Current User:", currentUser);
    console.log("2. Contacts:", contacts);
    console.log("3. Selected Contact:", selectedContact);
    console.log("4. Messages:", messages);
    console.log("5. Pending Transactions:", pendingTransactions);
    console.log("6. Loading States:", {
      isLoading,
      contactsLoading,
      messagesLoading,
      pendingTransactionsLoading
    });
  };

  // Check if we're stuck at loading or if there are errors
  if (isLoading) {
    console.log("Rendering loading state due to isLoading = true");
    return (
      <div className="h-screen w-full flex items-center justify-center bg-dark-background text-white">
        <div className="flex flex-col items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mb-4"></div>
          <p className="text-lg">Loading secure environment...</p>
          <button 
            onClick={debugAppState}
            className="mt-8 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            Debug (Check Console)
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-[#121212] text-white">
      <AppHeader 
        currentUser={currentUser} 
      />
      
      <main className="flex-1 flex overflow-hidden">
        <SidebarPanel
          currentUser={currentUser}
          contacts={contacts as Contact[]}
          selectedContact={selectedContact}
          onSelectContact={setSelectedContact}
          onAddContactClick={() => setIsAddContactModalOpen(true)}
          isLoading={contactsLoading}
        />
        
        <ChatPanel
          currentUser={currentUser}
          currentContact={selectedContact}
          messages={messages as Message[]}
          pendingMessages={pendingMessages}
          onSendMessage={handleSendMessage}
          onShowBlockchainInfo={() => setIsBlockchainInfoModalOpen(true)}
          isLoading={messagesLoading}
        />
      </main>
      
      <AddContactModal 
        isOpen={isAddContactModalOpen}
        onClose={() => setIsAddContactModalOpen(false)}
        onAddContact={handleAddContact}
      />
      
      <BlockchainInfoModal
        isOpen={isBlockchainInfoModalOpen} 
        onClose={() => setIsBlockchainInfoModalOpen(false)}
        pendingTransactions={pendingTransactions as Transaction[]}
      />
    </div>
  );
}
