import { createRoot } from "react-dom/client";
import RebuildApp from "./App.rebuild";
import "./index.css";

// Add title and meta tags for SEO
document.title = "Decentralized Secure Messaging";
const metaDescription = document.createElement('meta');
metaDescription.name = 'description';
metaDescription.content = 'Secure end-to-end encrypted messaging platform with blockchain verification for maximum privacy and security.';
document.head.appendChild(metaDescription);

// Use the rebuilt app with full features
createRoot(document.getElementById("root")!).render(<RebuildApp />);
